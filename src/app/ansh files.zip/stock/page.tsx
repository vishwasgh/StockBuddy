import React from 'react';
import TradingViewWidget from '../components/TradingViewWidget';
import StockScreener from '../components/StockScreener';

export default function StockPage() {
  return (
    <div className="container mx-auto px-4 py-8 pt-20">
      
      <div className="mb-8">
        <TradingViewWidget />
      </div>
      <div className="mt-12">
        <StockScreener />
      </div>
    </div>
  );
}

