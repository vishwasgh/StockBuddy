'use client';

import React from 'react';
import { notFound } from 'next/navigation';
import CryptoData from '@/app/components/CryptoData';
import CryptoPredictor from '@/app/components/CryptoPrediction'; // Import the CryptoPredictor component
import CryptoImageAnalysis from '@/app/components/CryptoImageAnalysis'; // Import the CryptoImageAnalysis component
import CryptoChart from '@/app/components/CryptoChart'; // Import the CryptoWidget component

export default function CryptoPage({ params }: { params: Promise<{ symbol: string }> }) {
  const resolvedParams = React.use(params); // Unwrap the params Promise
  const symbol = resolvedParams?.symbol.toUpperCase(); // Ensure symbol is uppercase

  if (!symbol) {
    return notFound();
  }

  return (
    <div className="container mx-auto px-4 py-8 pt-20">
      <h3 className="text-lg font-semibold">{symbol}</h3>
      <div className="mt-8 p-6 w-full h-96 bg-white rounded-lg shadow-lg"> {/* Add padding, width, and background color */}
        <CryptoChart symbol={symbol} /> {/* Pass the symbol to CryptoWidget */}
      </div>
      <div className="mt-8"> {/* Add some margin for spacing */}
        <CryptoData symbol={symbol} /> {/* Pass the symbol to CryptoData */}
      </div>
      <div className="mt-8"> {/* Add some margin for spacing */}
        <CryptoPredictor symbol={symbol} /> {/* Pass the symbol to CryptoPredictor */}
      </div>
      <div className="mt-8"> {/* Add some margin for spacing */}
        <CryptoImageAnalysis symbol={symbol} /> {/* Pass the symbol to CryptoImageAnalysis */}
      </div>
    </div>
  );
}