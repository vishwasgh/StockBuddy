// Backtest.tsx
"use client"

import type React from "react"
import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/app/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/app/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/app/components/ui/table"
import { Input } from "@/app/components/ui/input"
import { Button } from "@/app/components/ui/button"

interface Trade {
  EntryPrice: number
  ExitPrice: number
  "Profit&Loss": number
  EntryTime: string
  ExitTime: string
}

interface BacktestResult {
  "Win Rate %": number
  "Return %": number
  Trades: {
    EntryPrice: { [key: string]: number }
    ExitPrice: { [key: string]: number }
    "Profit&Loss": { [key: string]: number }
    EntryTime: { [key: string]: string }
    ExitTime: { [key: string]: string }
  }
}

interface BacktestData {
  results_best_returns: BacktestResult
  results_best_winrate: BacktestResult
}

interface BacktestProps {
  symbol: string;
}

const Backtest: React.FC<BacktestProps> = ({ symbol }) => {
  const [ticker, setTicker] = useState(symbol); // Initialize ticker with the symbol
  const [strategy, setStrategy] = useState("SmaCross")
  const [backtestData, setBacktestData] = useState<BacktestData | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fetchBacktestData = async () => {
    setIsLoading(true)
    setError(null)
    try {
      const response = await fetch(
        `http://localhost:2000/backtest?ticker=${ticker}&interval=1day&api=yfinance&s_name=${strategy}`,
      )
      if (!response.ok) {
        throw new Error("Failed to fetch backtest data")
      }
      const data = await response.json()
      setBacktestData(data)
    } catch (err) {
      setError("Error fetching backtest data. Please try again.")
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    fetchBacktestData()
  }

  const renderTrades = (trades: BacktestResult["Trades"]) => {
    const tradeCount = Object.keys(trades.EntryPrice).length
    const tradeRows = []

    for (let i = 0; i < tradeCount; i++) {
      tradeRows.push(
        <TableRow key={i}>
          <TableCell>{trades.EntryPrice[i].toFixed(2)}</TableCell>
          <TableCell>{trades.ExitPrice[i].toFixed(2)}</TableCell>
          <TableCell className={trades["Profit&Loss"][i] >= 0 ? "text-green-600" : "text-red-600"}>
            {trades["Profit&Loss"][i].toFixed(2)}
          </TableCell>
          <TableCell>{new Date(trades.EntryTime[i]).toLocaleDateString()}</TableCell>
          <TableCell>{new Date(trades.ExitTime[i]).toLocaleDateString()}</TableCell>
        </TableRow>,
      )
    }

    return tradeRows
  }

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="flex space-x-4">
        <Input
          type="text"
          value={ticker}
          onChange={(e) => setTicker(e.target.value)}
          placeholder="Enter stock ticker"
          className="max-w-xs"
        />
        <Button type="submit" disabled={isLoading}>
          {isLoading ? "Loading..." : "Run Backtest"}
        </Button>
      </form>

      {error && <div className="text-red-600">{error}</div>}

      {backtestData && (
        <Tabs defaultValue="best_returns">
          <TabsList>
            <TabsTrigger value="best_returns">Best Returns</TabsTrigger>
            <TabsTrigger value="best_winrate">Best Win Rate</TabsTrigger>
          </TabsList>
          <TabsContent value="best_returns">
            <BacktestResultTab result={backtestData.results_best_returns} renderTrades={renderTrades} />
          </TabsContent>
          <TabsContent value="best_winrate">
            <BacktestResultTab result={backtestData.results_best_winrate} renderTrades={renderTrades} />
          </TabsContent>
        </Tabs>
      )}
    </div>
  )
}

const BacktestResultTab: React.FC<{ result: BacktestResult; renderTrades: (trades: BacktestResult["Trades"]) => JSX.Element[] }> = ({ result, renderTrades }) => (
  <div className="space-y-6">
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <Card>
        <CardHeader>
          <CardTitle>Win Rate</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-2xl font-bold">{result["Win Rate %"].toFixed(2)}%</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Total Return</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-2xl font-bold">{result["Return %"].toFixed(2)}%</p>
        </CardContent>
      </Card>
    </div>
    <Card>
      <CardHeader>
        <CardTitle>Trade Details</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Entry Price</TableHead>
              <TableHead>Exit Price</TableHead>
              <TableHead>Profit/Loss</TableHead>
              <TableHead>Entry Date</TableHead>
              <TableHead>Exit Date</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>{renderTrades(result.Trades)}</TableBody>
        </Table>
      </CardContent>
    </Card>
  </div>
)

export default Backtest