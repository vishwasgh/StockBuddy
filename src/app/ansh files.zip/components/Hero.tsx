'use client'; // This directive ensures the component is rendered on the client side

import React, { useEffect, useRef } from 'react';

const Hero: React.FC = () => {
  const widgetContainer = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (widgetContainer.current) {
      const script = document.createElement("script");
      script.src = "https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js";
      script.type = "text/javascript";
      script.async = true;
      script.innerHTML = JSON.stringify({
        symbols: [
          { proName: "BSE:SENSEX", title: "SENSEX" },
          { proName: "BSE:TATAMOTORS", title: "Tata Motors" },
          { proName: "BITSTAMP:BTCUSD", title: "Bitcoin" },
          { proName: "BITSTAMP:ETHUSD", title: "Ethereum" },
          { proName: "BSE:RELIANCE", title: "Reliance" }
        ],
        showSymbolLogo: true,
        isTransparent: false,
        displayMode: "adaptive",
        colorTheme: "dark",
        locale: "en"
      });
      widgetContainer.current.appendChild(script);
    }

    return () => {
      // Clean up the widget on component unmount
      if (widgetContainer.current) {
        widgetContainer.current.innerHTML = ''; // Clear the container
      }
    };
  }, []);

  return (
    <section className="relative text-gray-600 body-font bg-[url('/background.jpeg')] bg-cover bg-center bg-opacity-30 h-screen">
      <div className="tradingview-widget-container" ref={widgetContainer}>
        <div className="tradingview-widget-container__widget"></div>
        <div className="tradingview-widget-copyright">
          <a href="https://www.tradingview.com/" rel="noopener nofollow" target="_blank">
            <span className="blue-text">Track all markets on TradingView</span>
          </a>
        </div>
      </div>
      <div className="flex items-center justify-center h-full">
        <h1 className="text-4xl font-bold text-white">Welcome to StockBuddy</h1>
      </div>
    </section>
  );
};

export default Hero;